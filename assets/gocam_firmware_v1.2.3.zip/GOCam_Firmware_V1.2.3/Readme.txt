
HOW TO UPDATE?
The classic method (manually copy the firmware file onto the SD card).
Firmware Upgrade (It would be better to upgrade when the battery is fully charged)
1. After downloading the firmware, unzip the downloaded file, find the IF-RC01.BRN file and copy it to the root directory of the microSD card. The firmware name should be confirmed as IF-RC01.BRN.
2. Disconnect from the computer, powering the camera via the mobile charger. And then turn on the camera with the micro SD card inserted. The camera will automatically update the firmware.
3. During the updating process,  Green light blink .
4. After about 2-3 minute, the camera will automatically shut down, the upgrade has completed.


---------------------------------------------------------------------------------------------------------------

V 1.2.3 update:




1. Support gyroscope data to be saved in SD card, file name: gyroDate*.csv


2, support video image stabilization software Gyroflow (0.3.0-beta)